﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartTwo
{
    
    

        public class Recipe
        {
            public string Name { get; set; }
            public List<Ingredient> Ingredients { get; set; }
            public List<Step> Steps { get; set; }

            public Recipe(string name)
            {
                Name = name;
                Ingredients = new List<Ingredient>();
                Steps = new List<Step>();
            }

            public void AddIngredient(string name, double quantity, string unit, int calories, string foodGroup)
            {
                Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup });
            }

            public void AddStep(string description)
            {
                Steps.Add(new Step { Description = description });
            }

            public void DisplayRecipe()
            {
                Console.WriteLine($"Recipe: {Name}");
                Console.WriteLine("Ingredients:");
                foreach (var ingredient in Ingredients)
                {
                    Console.WriteLine($"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}");
                }
                Console.WriteLine("Steps:");
                for (int i = 0; i < Steps.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {Steps[i].Description}");
                }
            }

            public int TotalCalories()
            {
                return Ingredients.Sum(ingredient => ingredient.Calories);
            }
        }

        public delegate void RecipeCaloriesNotification(string recipeName, int totalCalories);

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    public class Step
    {
        public string Description { get; set; }
    }
}

