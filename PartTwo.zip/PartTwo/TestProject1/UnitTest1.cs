
namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        public void TotalCalories_CalculatesCorrectly()
        {
           
            Recipe recipe = new Recipe("Test Recipe");
            recipe.AddIngredient("Ingredient 1", 100, "g", 50, "Group A");
            recipe.AddIngredient("Ingredient 2", 200, "g", 70, "Group B");
            recipe.AddIngredient("Ingredient 3", 150, "g", 80, "Group C");

            
            int totalCalories = recipe.TotalCalories();

            
            Assert.AreEqual(200, totalCalories); 
        }
    }
}

